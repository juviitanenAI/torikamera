# Tårget > 2026-01-21 8:16pm
https://universe.roboflow.com/trget/target-tso4q

Provided by a Roboflow user
License: CC BY 4.0

